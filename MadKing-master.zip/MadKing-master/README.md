
# Madking
用python写的CMDB系统
基于autohome 早期cmdb平台重构并优化的教学版本，实现了如下功能：
•   存储各种IT资产信息
•   数据可手动添加
•   硬件信息可自动收集
•   硬件信息可自动变更
•   可对其它系统灵活开放API
•   API接口安全认证


# 项目讲解视频
http://edu.51cto.com/course/course_id-5909.html

# python自动化交流群
Python自动化交流群 29215534

# 项目截图
 ![image](https://github.com/triaquae/MadKing/blob/master/share/screenshots/dashboard.png)
 ![image](https://github.com/triaquae/Madking/blob/master/share/screenshots/asset_list.png)

